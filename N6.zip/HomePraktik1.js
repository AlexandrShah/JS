var user = {
    name: "John Smith",
    getName: function() {
        console.log(this.name);
    },
    setName: function (name) {
        this.name = name;
        this.lastName = "qqqqq";
    }
};
user.getName("Mr.Anderson");
user.setName('Max');
user.getName();

console.log(user);

var user1 = {
    name: 'John Smith',
    getName: function(title) {
        console.log(title + ' ' + this.name);
    }
};

var user2 = {
    name: 'Richard'
};

user1.getName('Mr.');
user1.getName.apply(user2, ["The King"]);


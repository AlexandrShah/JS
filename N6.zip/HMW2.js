// Создать скрипт, получающий от пользователя ссылку
// и переадресовывающий его по указанному адресу (использовать функции)

var url = prompt("type url");

function GoGoUrl(){
    location.href="https://"+url;
}
setTimeout( 'GoGoUrl()', 1000 );

// Редирект только когда указано https://


// Создать функцию для расчета произведения двух чисел, которая вызывается так: name(digit1)(digit2).
    // Функция должна возвращать результат (не выводить его!)


function calc() {
    var digit1 =parseInt(prompt(" type number1"));
    return function () {
       var digit2 = parseInt(prompt("type number2"));
       return digit1*digit2;
    }
}
console.log(calc()());

// Не уверен что правильно выполнил. Т.к. не совсем понял по поводу возвращения и вывода. Спрощу на уроке.
// Я так понимаю что возвращение через return. Надеюсь)

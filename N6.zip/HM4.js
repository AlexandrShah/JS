var users = {
    data: [
        {name: 'John Smith'},
        {name: 'Ellen Simons'}
    ],
    showFirst: function () {
        console.log(this.data[0].name);
    }
};

var cars = {
    data: [
        {name: "Mitsubishi Lancer" },
        {name: "Chevrolet Impala" }
    ]
};

cars.showFirst = users.showFirst.bind(cars);
cars.showFirst();

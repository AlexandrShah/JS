//Создать объект автомобиля с функциями вывода на экран и присвоения этого автомобиля владельцу
// (записать в автомобиль id-владельца) и продемонстрировать работу объекта.

function Owner(id,name,lastName, age) {
    this.id =id;
    this.name=name;
    this.lastName=lastName;
    this.age = age;
    function buyCar(car){
        // Я так и не понял что нужно сделать с функцией. Точнее я даже не понимаю зачем функция для пуша
    }
    this.car=[];
    this.showInfo = function () {
        console.log(this.name, this.lastName, this.age , this.id, this.car)
    }
}

var ivan = new Owner('001',"Ivan","Ivanov",39);
var armen = new Owner('002',"Armen","Jigurtyan",51);
var hanzo = new Owner('003',"Hanzo","Shimada",36);
var anderson = new Owner('004',"Thomas","Anderson",33);
var monika = new Owner('005',"Monika","Anarietto",21);

console.log(ivan,armen,hanzo,anderson,monika);

armen.showInfo();

function Cars(id,name,price, year) {
    this.id =id;
    this.name=name;
    this.price=price;
    this.year = year;
    this.ownerId=[];
    this.showInfo = function () {
        console.log(this.name, this.price, this.year , this.id, this.ownerId)
    }
}

var lada = new Cars('0010',"Lada","5000$",2008);
var priora = new Cars('0020',"Priora","6000$",2013);
var kia = new Cars('0030',"Cerata","13000$",2011);
var honda = new Cars('0040',"Civic","14500$",2013);
var lamb = new Cars('0050',"Lamborghini","200000$",2016);

console.log(lada,priora,kia,honda,lamb);

lamb.ownerId.push(monika.id);
lamb.showInfo();
honda.ownerId.push(hanzo.id);
honda.showInfo();
kia.ownerId.push(anderson.id);
kia.showInfo();
priora.ownerId.push(armen.id);
priora.showInfo();
lada.ownerId.push(ivan.id);
lada.showInfo();




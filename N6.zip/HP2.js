var student1 = {
    name: "Ivan",
    lastName:"Ivanov",
    finalMark:100,
    getunfo:function () {
        console.log(this.name, this.lastName, this.finalMark);
    }
};
var student2 = {
    name: "Sidor",
    lastName:"Sidorov",
    finalMark:100,
    getunfo:function () {
        console.log(this.name, this.lastName, this.finalMark);
    }
};
var student3 = {
    name: "Maria",
    lastName:"Ivanova",
    finalMark:100,
    getunfo:function () {
        console.log(this.name, this.lastName, this.finalMark);
    }
};
